const logo = {
  alt: 'Kitty McKitty',
  url: 'https://i.guim.co.uk/img/media/26392d05302e02f7bf4eb143bb84c8097d09144b/446_167_3683_2210/master/3683.jpg?width=620&dpr=1&s=none',
  width: 60,
};

const menu = {
  link1:{
    copy:'safety',
    url:'#safety'
  },
  link2:{
    copy:'services',
    url:'#services'
  }
};

const Menu = () => {
  return (
    <>
      <section>
        <nav className='navbar fixed-top'>
          <div className='container-fluid'>
          <a className='navbar-brand' href='#safety'>

          <img src={logo.url} className='avatar' alt={logo.alt} width={logo.width} />
          </a>
          <button className='btn btn-light' type='button' data-bs-toggle='offcanvas' data-bs-target='#offcanvasRight' aria-controls='offcanvasRight'><svg width='40px' height='40px' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'><g id='SVGRepo_bgCarrier' strokeWidth='0'/><g id='SVGRepo_tracerCarrier' strokeLinecap='round' strokeLinejoin='round'/><g id='SVGRepo_iconCarrier'> <g clipPath='url(#clip0_429_11066)'> <path d='M3 6.00092H21M3 12.0009H21M3 18.0009H21' stroke='#292929' strokeWidth='2.5' strokeLinecap='round' strokeLinejoin='round'/> </g> <defs> <clipPath id='clip0_429_11066'> <rect width='24' height='24' fill='white' transform='translate(0 0.000915527)'/> </clipPath> </defs> </g></svg></button>
          </div>
        </nav>
        <div className='offcanvas offcanvas-end' tabIndex='-1' id='offcanvasRight' aria-labelledby='offcanvasRightLabel'>
          <div className='offcanvas-header'>
            <button type='button' className='btn-close' data-bs-dismiss='offcanvas' aria-label='Close'></button>
          </div>
          <div className='offcanvas-body'>
            <a href={menu.link1.url}>{menu.link1.copy}</a><br/>
            <a href={menu.link2.url}>{menu.link2.copy}</a>
          </div>
        </div>
      </section>
    </>
  )
}

export default Menu;
