const about = {
  title: 'Lady Kitty McKitten',
  imageUrl: 'https://i.guim.co.uk/img/media/26392d05302e02f7bf4eb143bb84c8097d09144b/446_167_3683_2210/master/3683.jpg?width=620&dpr=1&s=none',
  imageWidth: 300,
  copy: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
};

export default function About() {
  return (
    <>
    <section className='container-fluid px-0 bg-gradient-babyblue'>
    <section className='container-fluid bg-gradient-babyblue'>
      <div className='container justify-content-md-center py-5'>
      <div className='row flex-wrap-reverse'>
        <div className='col-md-6'>
          <h2>{about.title}</h2>
          <br/>
          {about.copy}
        </div>
        <div className='col-md-6 pb-3 d-flex justify-content-center'>
        <img src={about.imageUrl} alt='' width={about.imageWidth} />
        </div>
        </div>
      </div>
    </section>
    </section>
    </>
  );
}