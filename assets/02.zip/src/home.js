
const today = new Date();
const formatDate = (date) => {
  return new Intl.DateTimeFormat(
    'en-US',
    { weekday: 'long' }
  ).format(date);
}

const home = {
  title: 'Kitty McKitty',
  imageUrl: 'https://i.guim.co.uk/img/media/26392d05302e02f7bf4eb143bb84c8097d09144b/446_167_3683_2210/master/3683.jpg?width=620&dpr=1&s=none',
  imageWidth: 300,
};

export default function Home() {
  return (
    <>
    <section className='container-fluid px-0 min-vh-100 bg-image'>
    <section className='container-fluid px-0 min-vh-100 d-flex justify-content-center align-items-center bg-gradient-white'>
      <article>
          <h2>Welcome to my app</h2>
          <h1>{home.title}</h1>
          <p>Hello there. How do you do?</p>
          <img src={home.imageUrl} className='avatar' alt='' width={home.imageWidth} />
          <p>Today is {formatDate(today)}</p> 
      </article>
    </section>
    </section>
    </>
  );
}