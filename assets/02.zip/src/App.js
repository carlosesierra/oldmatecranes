import './App.css';
import Menu from './menu.js';
import Home from './home.js';
import About from './about.js';
import Services from './services.js';
import Safety from './safety.js';


export default function App() {
  return (
    <section className='container-fluid px-0'>
      <Menu />
      <Home />
      <About />
      <Services />
      <Safety />
    </section>
  );
}