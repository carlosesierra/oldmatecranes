const list = {
  id:'services',
  title: 'Lady Kitty McKitten',
  copy: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
};

const Services = () => (
    <section className='container-fluid px-0 min-vh-100 parallax' id={list.id}>
    <section className='container px-0 min-vh-100 d-flex justify-content-center align-items-center'>
      <article className='col-md-6 text-white'>
        <h1>{list.title}</h1>
        <p>{list.copy}</p>
      </article>
    </section>
    </section>
  )

export default Services;